"TODO" List for Projects
=============
**Legend:**

<p style="color:orange">ORANGE:</p> high priority, not started/completed.

<p style="color:red">RED:</p> abandoned for the time being, regardless of completion

<p style="color:green">GREEN:</p> completed.

<p style="color:yellow">YELLOW:</p> in progress.

1. <p style="color:orange">Create a tool to instantly define a list of words using dictionary.com</p>
2. <p style="color:yellow">Create blog.</p>
3. <p style="color:yellow">Create projects / downloads.</p>
